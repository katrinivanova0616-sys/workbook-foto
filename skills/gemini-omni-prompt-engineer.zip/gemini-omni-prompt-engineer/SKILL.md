---
name: gemini-omni-prompt-engineer
description: Промт-инженер для Gemini Omni Flash — нейросети Google для генерации видео. Используй этот скилл когда нужно написать, улучшить или исправить промт для Gemini Omni Flash — генерация видео по тексту, анимация изображения, мультиреференс, редактирование видео, multi-turn стратегия. Триггер: "промт для Omni", "Gemini Omni промт", "Google Omni видео", "напиши промт для гугл", "gemini video", "google flow промт".
---

# Gemini Omni Flash — Промт-инженер
## Актуально на июнь 2026

---

## ЧТО ТАКОЕ GEMINI OMNI FLASH

Gemini Omni Flash — нейросеть Google класса "any-to-any world model", анонсирована на Google I/O 19 мая 2026.
Принимает на вход: текст, изображения, аудио, видео — одновременно.
Выдаёт: видео до 10 секунд с синхронизированным аудио.

**Где работает:**
- Gemini App (AI Pro $19.99/мес, AI Ultra ~$249/мес)
- Google Flow / Google Flow Music
- YouTube Shorts и YouTube Create App (бесплатно)
- API — в планах, дата не объявлена (июнь 2026)

**Лимиты:**
- Gemini App: ~3 видео за сессию (квота по compute)
- Google Flow: ~10 видео
- Длительность клипа: 10 секунд (политика, не техническое ограничение)
- Каждое видео содержит SynthID watermark — невидимый, верифицируется в Gemini App и Google Search

---

## АБСОЛЮТНЫЕ ПРАВИЛА

1. **ПОЛНЫЙ ПРОМТ ВСЕГДА.** Если просят исправить — присылаешь весь промт целиком.
2. **6 ИЗМЕРЕНИЙ ОБЯЗАТЕЛЬНО.** Официальный фреймворк Google: shot/motion, style, lighting, location, action, text rendering. Чем больше измерений покрыто — тем лучше результат.
3. **КАМЕРА ПЕРВОЙ.** Инструкция по камере задаёт визуальную грамматику всего клипа — пиши её в начало промта.
4. **MULTI-TURN — главная фишка Omni.** Не переписывай промт с нуля — используй conversational editing: меняй одну переменную за раз, сохраняя остальное.
5. **PRESERVE-инструкция обязательна** при редактировании: "Change X. Keep everything else identical."
6. **Аудио — полноценный input.** Omni синхронизирует видео с загруженным аудио, не только генерирует звук.
7. **World-knowledge grounding** — используй реальные понятия (физика, история, наука, география) — модель понимает их и применяет к генерации.

---

## ОФИЦИАЛЬНЫЙ ФРЕЙМВОРК — 6 ИЗМЕРЕНИЙ

```
[1. SHOT / MOTION]   — тип кадра, движение камеры
[2. STYLE]           — визуальный стиль, эстетика
[3. LIGHTING]        — освещение конкретно
[4. LOCATION]        — место, среда, фон
[5. ACTION]          — что происходит, кто действует
[6. TEXT RENDERING]  — если нужен текст в кадре
```

### Полный шаблон одного промта:
```
[Camera]: [тип кадра + движение камеры].
[Subject/Action]: [кто + что делает максимально подробно].
[Location]: [где, детали среды].
[Lighting]: [тип освещения конкретно].
[Style]: [визуальный стиль, цветовая гамма, mood].
[Audio]: [звук или музыка].
[Text]: [если нужен текст в кадре — содержание, позиция, стиль].
```

---

## СТРУКТУРА MULTIMODAL ПРОМТА

Omni принимает несколько input'ов одновременно. В промте нужно явно указать что откуда берётся.

**Шаблон референс-промта:**
```
Using [изображение/видео/аудио] as reference:
[что именно взять из этого референса].
Generate: [описание сцены].
Keep consistent: [что должно остаться неизменным].
```

**Примеры:**
```
Using the uploaded image as visual reference for character appearance,
generate a 10-second clip of [описание].
Keep face and outfit consistent throughout.

Apply the motion and camera style from the uploaded video to [описание сцены].
Match the pacing exactly.

Using uploaded audio track as soundtrack,
generate video that matches the rhythm and mood of the music.
[описание видео].
```

**Типы референсов:**
- Изображение → внешность персонажа, стиль, локация
- Видео → движение камеры, пейсинг, стиль
- Аудио → ритм, настроение, синхронизация движений

---

## MULTI-TURN СТРАТЕГИЯ — главная фишка Omni

Omni редактирует видео в диалоге — не нужно стартовать с нуля при каждом изменении.

### 4-шаговый workflow:

**Шаг 1 — Базовый промт (широко):**
```
[Общее описание сцены, все 6 измерений].
```

**Шаг 2 — Уточнение камеры:**
```
Change the camera to [новое движение]. Keep everything else identical.
```

**Шаг 3 — Уточнение элемента:**
```
Change [конкретный элемент — свет/персонаж/действие]. Keep everything else identical.
```

**Шаг 4 — Финальная правка:**
```
[Финальное уточнение]. Preserve all previous changes.
```

### Правила multi-turn:
- Меняй ОДНУ переменную за раз
- Всегда добавляй "Keep everything else identical" или "Preserve all previous changes"
- Не переписывай весь промт — это сбрасывает состояние
- 3-5 итераций дают лучший результат чем один длинный промт

---

## КАМЕРА — технические термины

Omni реагирует на кинематографические термины как на команды.

| Термин | Что делает |
|--------|-----------|
| `locked off` | Статичная камера, без движения |
| `oner` | Один непрерывный план без монтажа |
| `push in` | Медленный наезд на объект |
| `pull back` | Медленный отъезд от объекта |
| `dolly zoom` | Вертиго-эффект: zoom + обратное движение |
| `orbit` | Облёт вокруг объекта |
| `tracking shot` | Камера следует за объектом |
| `crane up` | Подъём камеры вверх |
| `handheld` | Живая камера, лёгкая тряска |
| `Dutch angle` | Наклон камеры, динамическое напряжение |
| `POV` | От первого лица |
| `overhead` | Строго сверху вниз, 90 градусов |

**Правило:** пиши camera move первым в промте — он задаёт визуальную грамматику всего клипа.

---

## ОСВЕЩЕНИЕ — конкретные описания

| Тип | Как писать |
|-----|-----------|
| Студийный | `soft beauty dish from front, subtle fill light, no harsh shadows` |
| Золотой час | `low warm sunlight at 15 degrees, long shadows, amber highlights` |
| Кинематограф | `teal and orange grade, warm highlights, cool shadows` |
| Ночной город | `neon reflections on wet pavement, harsh contrast street lighting` |
| Натуральный | `overcast daylight, diffused soft shadows, even exposure` |
| Retail / салон | `warm overhead track lighting, soft specular on surfaces` |
| Драматический | `single hard key light from side, deep shadows, high contrast ratio` |

---

## ТЕКСТ В КАДРЕ — уникальная фича Omni

Omni умеет рендерить читаемый текст внутри видео — это редкость среди видеомоделей.

```
Display the text "[текст]" in [позиция: top/center/bottom-right/etc],
appearing at [X seconds], in [стиль: bold white sans-serif / gold italic / etc].
Text remains visible for [длительность].
```

**Для брендинга:**
```
Logo text "BRAND NAME" appears in bottom-right corner throughout the clip,
white bold caps, subtle drop shadow, no animation.
```

**Для субтитров:**
```
Subtitles appear at the bottom synchronized with the narration.
White text, black outline, readable size.
```

---

## WORLD-KNOWLEDGE GROUNDING

Omni понимает реальный мир — используй это.

**Примеры применения:**
```
Apply realistic fluid dynamics to the water — accurate surface tension and splash physics.
Use accurate golden hour lighting for 47 degrees north latitude in late October.
The character moves with the biomechanics of a trained ballet dancer.
Render the fabric with accurate silk light refraction properties.
```

Чем конкретнее реальный факт — тем точнее модель его воспроизведёт.

---

## ТИПЫ ЗАДАЧ — шаблоны

**T2V (текст в видео):**
```
[Camera] locked off / push in / tracking shot.
[Action]: [персонаж] [действие подробно].
[Location]: [место конкретно].
[Lighting]: [тип освещения].
[Style]: [эстетика, цветовая гамма].
[Audio]: natural ambient sounds / [описание музыки].
```

**I2V (анимация изображения):**
```
Animate this image. Add [конкретное движение].
Keep composition, colors, and subject identical.
[Camera move если нужен].
[Что должно двигаться и как именно].
```

**Редактирование видео:**
```
Change [конкретный элемент] in this video.
Keep everything else identical — composition, characters, lighting, pacing.
[Описание изменения].
```

**Style transfer:**
```
Apply the visual style from the reference image to this video.
Preserve core motion and timing. Adjust color palette to match.
Keep identity consistent throughout.
```

**Мультиреференс (персонаж + локация + аудио):**
```
Character appearance references the uploaded portrait image.
Environment references the uploaded location photo.
Video rhythm references the uploaded audio track.
Generate: [описание сцены].
Maintain consistent character features throughout.
```

---

## ГОТОВЫЕ БЛОКИ

**Блок консистентности персонажа:**
```
Keep the character's face, outfit, and physical features
identical across every frame. No identity drift.
Same person visible from [timestamp] to [timestamp].
```

**Блок продакт-видео:**
```
Product hero shot. Locked off camera. Studio lighting — soft key from 45 degrees,
white bounce fill, dark gradient background.
[Продукт] rotates slowly [clockwise/counterclockwise].
No motion blur. Sharp focus throughout.
Photorealistic render quality.
```

**Блок рекламы для Reels/Shorts:**
```
Vertical 9:16. Push in camera starting wide, ending medium close-up.
[Персонаж] [действие] in [локация].
[Lighting]. [Style — cinematic color grade].
Pacing: fast cut energy. Total 10 seconds.
No music — natural ambient sounds.
```

**Блок multi-turn preserve:**
```
Change [одна вещь]. Keep everything else identical:
same camera angle, same character appearance, same lighting,
same background, same pacing, same audio.
```

---

## ТИПОВЫЕ ОШИБКИ И РЕШЕНИЯ

| Проблема | Решение |
|----------|---------|
| Лицо меняется между кадрами | `Keep the character's face identical across every frame. No identity drift.` |
| Текст нечитаемый | Уточни шрифт, размер, позицию, контраст фона |
| Камера трясётся | `locked off camera` или `smooth gimbal movement, no shake` |
| Результат слишком generic | Покрой все 6 измерений, добавь world-knowledge grounding |
| Multi-turn сбрасывает изменения | Добавляй `Preserve all previous changes` в каждый следующий промт |
| Аудио не совпадает с видео | Загружай аудио как input, не описывай словами |
| Квота кончилась быстро | Failed requests теперь не считаются (фикс от 29 мая 2026) |

---

## ЛИМИТЫ

| Параметр | Значение |
|----------|----------|
| Длительность клипа | 10 секунд (политика Google, не техн. ограничение) |
| Inputs | текст + изображения + аудио + видео одновременно |
| Доступ | Gemini App, Google Flow, YouTube Shorts/Create |
| API | В планах, без даты (июнь 2026) |
| Watermark | SynthID на каждом клипе, невидимый |
| Multi-turn оптимум | 3-5 итераций от базового промта |

