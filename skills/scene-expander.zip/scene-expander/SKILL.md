---
name: scene-expander
description: >
  Expand a one-line idea into a full, detailed visual scene with environment, lighting,
  atmosphere, and camera direction. Use this skill when the user says "разверни идею",
  "сделай из этого сцену", "у меня есть идея — помоги описать", "хочу такую сцену но не знаю как написать",
  "опиши сцену подробно", or gives a short concept like "девушка в кафе" or "закат на крыше"
  and needs it turned into a full, generatable prompt.
  Always use this skill — it adds environment depth, lighting logic, atmospheric details,
  and camera direction that make the difference between a flat and a cinematic result.
---

# Scene Expander Skill

Transforms a simple idea into a fully realized visual scene.
Adds everything the AI model needs to generate something cinematic:
environment, light, atmosphere, texture, camera, mood.

---

## Workflow

1. **Receive concept** — one line, keyword, or rough idea
2. **Ask one question if needed** — photo or video? character included?
3. **Expand the scene** — fill all 6 layers
4. **Output prompt** — EN + RU, with copy buttons
5. **Offer variants** — suggest 2–3 alternative angles or moods

---

## The 6 Layers of a Scene

Every scene needs all 6. Missing layers = flat, generic results.

### Layer 1: Subject & Action
Who or what is in the frame and what are they doing?
- Be specific: "sitting with legs crossed, looking out the window" not "sitting"
- Include small gestures: "one hand wrapped around a coffee cup"
- If no character — describe the anchor object or element

### Layer 2: Environment
Where exactly is this happening?
- Location type: interior / exterior / urban / nature / studio
- Specific place: "corner table of a small Parisian café, marble countertop, vintage espresso machine in background"
- Time of day: morning / golden hour / midday / blue hour / night
- Weather if exterior: overcast / sunny / rainy / misty / windy

### Layer 3: Light
The single most important layer. Describes WHERE light comes from.
- Source: window / overhead / practical lamp / neon / sunlight / candle / studio
- Direction: from left / from behind / overhead / below
- Quality: soft and diffused / hard and directional / warm / cool / flickering
- Effect on subject: "warm side light catching the steam from the cup"

### Layer 4: Atmosphere & Texture
The feeling of the space.
- Air quality: hazy / crisp / steamy / dusty / foggy
- Ambient elements: background noise implied, people blurred in BG, movement
- Surface textures visible: worn wood, cold concrete, soft linen, wet pavement
- Color temperature of the space: warm amber / cool blue / neutral

### Layer 5: Camera
How are we seeing this?
- Shot type: close-up / medium / full body / wide establishing
- Lens feel: 35mm (natural) / 50mm (standard) / 85mm (compressed, flattering) / 24mm (wide)
- Angle: eye level / slightly above / low angle / overhead (flat lay)
- Movement: static / slight handheld drift / slow push-in / tracking
- Depth of field: sharp focus on subject + bokeh background / everything in focus

### Layer 6: Mood Summary
2–3 words that capture the emotional register.
Used at the end to unify all layers.
Examples: "quiet and intimate" / "tense and raw" / "dreamy and nostalgic" / "cold and editorial"

---

## Expansion Rules

- **More specific = better results.** "A café in Paris" → "corner table, small brasserie, black-and-white tiled floor, frosted glass windows letting in grey morning light"
- **Light logic must be consistent.** If it's golden hour outside, interior near a window gets warm side light — not overhead fluorescent.
- **Atmosphere implies sound.** Think about what you'd hear — it helps describe the scene more accurately even in image prompts.
- **Don't add everything.** Scenes with 10 competing elements confuse the model. One strong atmosphere > five weak details.

---

## Variants to Offer

After the main scene — always offer 2 quick alternatives:

```
Вариант A: [different time of day or light]
Вариант B: [different camera angle or shot type]
```

Let the user choose or mix elements.

---

## Output Format

**Scene Card** containing:
- Expanded scene — EN prompt (copy button)
- Expanded scene — RU prompt (copy button)
- Technical tags appropriate for photo or video
- 2 quick variant suggestions

---

## Example

**Input:** "девушка в кафе утром"

**Layer expansion:**

- Subject: young woman sitting at a small corner table, one hand wrapped around a ceramic coffee cup, looking out the window, slight smile, relaxed posture
- Environment: small independent café, Paris-style brasserie, black-and-white tiled floor, round marble table, vintage espresso machine visible behind the counter, a few other patrons blurred in background
- Light: soft grey morning light coming through large frosted windows from the left, diffused and even, no harsh shadows, slight warm glow from a pendant lamp above
- Atmosphere: quiet and unhurried, steam rising from the cup, muffled street sounds implied, slightly cool color temperature warmed by the lamp
- Camera: medium shot, 50mm lens, eye level, static with slight handheld drift, shallow depth of field — subject sharp, background softly blurred
- Mood: quiet and intimate, nostalgic, soft

**EN Prompt:**
```
[CHARACTER] — sitting at a small corner table in a Paris-style brasserie,
one hand wrapped around a ceramic coffee cup, looking out the window with a slight smile,
relaxed posture. Black-and-white tiled floor, round marble table,
vintage espresso machine behind the counter, patrons softly blurred in background.
Soft grey morning light from large frosted windows on the left, diffused, no harsh shadows,
slight warm glow from a pendant lamp above. Steam rising from the cup.
Medium shot, 50mm lens, eye level, static with slight handheld drift, shallow depth of field.
Shot on 35mm film, Kodak Portra 400, natural grain, no CGI, photorealistic, editorial.
IMPORTANT: preserve face identity, sharp facial features, consistent character look.
Mood: quiet, intimate, nostalgic.
```

**RU Prompt:**
```
[ПЕРСОНАЖ] — сидит за маленьким угловым столиком в парижском бистро,
одна рука обнимает керамическую кофейную чашку, смотрит в окно с лёгкой улыбкой,
расслабленная поза. Чёрно-белая плитка на полу, круглый мраморный стол,
винтажная кофемашина за стойкой, другие посетители размыты на фоне.
Мягкий серый утренний свет из больших матовых окон слева, рассеянный, без жёстких теней,
тёплое свечение подвесной лампы. Пар над чашкой.
Средний план, объектив 50 мм, уровень глаз, статика с лёгким дрейфом, малая глубина резкости.
Съёмка на 35-мм плёнку, Kodak Portra 400, натуральное зерно, без CGI, фотореалистично.
ВАЖНО: сохранить идентичность лица, чёткие черты, единообразный образ.
Настроение: тихое, камерное, ностальгическое.
```

**Варианты:**
- A: та же сцена, но вечер — тёплый свет свечи, тёмный фон за окном
- B: та же сцена сверху — overhead flat lay на стол, чашка и руки крупным планом
