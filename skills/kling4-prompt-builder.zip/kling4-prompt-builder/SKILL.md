---
name: kling4-prompt-builder
description: Промт-инженер для Kling 4.0 (Kuaishou, релиз 15.10.2026) от PROF AI — kling.ai, Higgsfield (kling4_0), fal (kling/v4). Используй этот скилл всегда, когда нужно написать, исправить или улучшить промт для Kling 4.0 — ролики 3–30 секунд одним проходом, Omni Reference до 15 файлов (10 картинок, 5 видео до 30 с в сумме, 7 элементов, 3 голоса), видео-референс камеры и движения, превиз-болванка из Blender (white-model), один непрерывный дубль или мульти-шот, ключевые кадры (до 10), редактирование видео (Edit @Video1), раскадровка по таймкодам, актёрская игра каждого персонажа в каждом бите, звук и реплики. Выдаёт промт в двух версиях — русскую для проверки и английскую для вставки — и проверяет английскую скриптом. Триггеры — «промт для клинг», «kling 4», «kling 4.0», «клинг 4», «напиши промт для kling», «превиз в kling», «omni reference», «сгенерируй в клинге», «kling4_0».
---

# Kling 4.0 — промт-инженер

**Скилл от PROF AI** · Kling 4.0 · kling.ai / Higgsfield / fal

Собран из официального «Kling 4.0 User Guide» (14.10.2026), документации API Kling 4.0, страниц моделей на Higgsfield и fal и отзывов креаторов. Наш опыт с Seedance 2.5 (ракурс первым, игра телом, роли референсов) перенесён сюда там, где он не противоречит гайду Kling. Что проверено на наших генерациях, а что взято из документации, помечено явно.

---

## ГЛАВНОЕ ОТЛИЧИЕ ОТ SEEDANCE: ОПИСЫВАЙ, А НЕ ЗАПРЕЩАЙ

Официальный принцип Kling 4.0: **описательный язык, минимум абстракций и минимум запретов.** Цитата гайда: «Negative prompts can increase the likelihood of errors. Only two types of negative instructions are truly necessary: no subtitles and no background music».

Отсюда три правила, которых нет в Seedance-скилле:
1. **Отдельного негативного блока нет.** Всё, что должно быть, пишется позитивно в блоке `POSITIVE CONSTRAINTS`: не «без открытых дверей», а «four doors closed from start to end».
2. **Обязательные запреты — только два:** `No subtitles` и `No background music` (когда музыка не нужна). Модель добавляет их по умолчанию.
3. **Вместо оценки — визуальный факт.** Не «premium look», а «side backlighting outlines the edges, the background is blurred, fine matte grain on the surface».

| Не надо ❌ | Надо ✅ |
|---|---|
| premium look | side backlighting outlines the object's edges, blurred background, fine matte grain |
| vintage feel | yellowed walls, worn furniture edges, warm incandescent light |
| cinematic, epic, stunning | 24mm, low angle, warm tungsten key from the left, teal shadows, fine grain |
| «не показывай лицо, пока он говорит по телефону» | he is shown in profile while talking on the phone |

---

## ПРАВИЛО НОМЕР ОДИН: РОЛЬ КАЖДОГО ФАЙЛА

Гайд: «If you provide only asset IDs without specifying their roles, the model will infer their intended use, making the results less predictable».

Файлы нумеруются **в порядке загрузки**: `@Image1`, `@Image2`, … и отдельно `@Video1`, `@Video2`, `@Element1`. Картинки и видео ведут свою нумерацию.

Для каждого файла — что он задаёт, что сохранить и **что из него не брать**:

```
@Image1 defines the scene. Preserve its spatial layout, furnishings and lighting.
Do not copy the faces of its guests.
@Image2 is the only source for the heroine: her face, hair and outfit.
Do not take the pose, the facial expression or the grey background.
```

**Реф-карта тащит свою съёмочную среду** (проверено на Seedance, на Kling ведём себя так же): павильон, серый фон, линии сетки 2×2 лезут в окна, отражения и фон. Для каждой карточки пиши, какую среду не брать.

**Карточка персонажа даёт внешность, но не игру.** Пиши «do not take the pose and the facial expression», а позу и эмоцию — в `ACTING` каждого бита.

Официальные формулы ролей (копируй и подставляй):

| Задача | Формулировка из гайда |
|---|---|
| Несколько героев | Reference the facial features of the characters in @Image1, @Image2 and @Image3, keeping them strictly consistent. |
| Движение из видео | Reference the fighting moves and attack timing in @Video1. Use @Image1 and @Image2 as the character appearance references. |
| Камера из видео | Reference the camera path and pacing of @Video1. Replace the element with the car in @Image1 and the background with @Image2. |
| Композиция | Reference the composition of @Image1 and preserve it exactly. |
| Раскадровка-картинка | Use the storyboard in @Image2 as the director-approved sequence of shots… Do not render the storyboard itself. Avoid pencil-sketch textures, grids, title bars… |
| Первый кадр + видео | @Image1 is the first frame. @Video1 is the reference for camera, motion, timing and cuts. Recreate @Video1 shot-for-shot… |

---

## ПРАВИЛО НОМЕР ДВА: РАКУРС ПЕРВЫМ В КАЖДОМ БИТЕ

Kling 4.0 лучше прошлых версий понимает камеру (официально: push-in, pull-out, pan, tracking, orbit «more natural and stable»). Но ракурс по-прежнему пишется **первым в каждом бите** и подробно — это главный урок Seedance, и официальные длинные примеры Kling делают так же: у каждого шота свой `OPTICS` (мм и угол обзора) и свой `CAMERA`.

Схема: **точка съёмки → высота в метрах или сантиметрах → угол к объекту → фокусное (мм, можно с FOV в градусах) → что в фокусе → движение камеры как путь → и только потом что происходит.**

```
3–5s
CAMERA: 1.7 m high, 1.5 m from the right side of the car, level with the windows,
tracking sideways toward the rear, 24mm, focus through the open front-right window
on the driver's face.
ACTION: …
ACTING: …
```

Движение камеры — **путь, а не две точки**: «rises from the floor to 1.2 m and moves toward the right side of the car», а не «камера внизу → камера сбоку». Две точки модель соединит склейкой.

Тряска камеры у Kling — настраиваемый параметр, а не случайность. В официальных примерах: «handheld SETTLE: visible breathing sway, slight roll, small delayed corrections», «Not a gimbal, slider, tripod lock-off, drone». Нужна плавная — пиши «smooth stabilized flying camera, no handheld shake».

---

## ПРАВИЛО НОМЕР ТРИ: АКТЁРСКАЯ ИГРА ТЕЛОМ В КАЖДОМ БИТЕ

В официальном 15-блочном шаблоне Kling есть отдельный блок `CHARACTER ACTING`, а в примерах эмоции расписаны телом: «Her eyebrows lift slightly on "love", her cheeks rise on "confident", and her final smile reaches both eyes». Это ровно наше правило из Seedance.

В каждом бите, где виден человек, поле `ACTING:` про каждого персонажа:
1. **Поза** — не «стоит», а «leans her shoulder against the wall, arms crossed, weight on one leg».
2. **Действие руками и телом** по порядку.
3. **Эмоция телом, не словом** — брови, глаза, рот, руки, плечи, голова. «Scared» модель не нарисует, «eyes bulge, eyebrows shoot up, mouth wide open, shoulders up at his ears» — нарисует.
4. **Манера речи** — темп, громкость, интонация, куда смотрит.
5. **Жест на слово:** «on the word “блендер” she raises an eyebrow and nods at the camera».
6. **Массовка:** что делают люди вокруг. Не должны говорить — «the guests only scream, they say no words».

Кадр без людей: `ACTING: no people in frame.` — так видно, что бит проверен.

Приём из официальных примеров: внутренний монолог — `INNER, UNSPOKEN: "This feels completely like me."` Даёт лицу состояние без лишних слов в звуке.

---

## ФОРМАТ ВЫДАЧИ — две версии

### Подпись

Выдачу промта открывай одной строкой:

```
Промт по скиллу PROF AI · Kling 4.0
```

Один раз, перед русской версией. **Внутрь промта подпись не попадает** — Kling рендерит текст в кадре хорошо, и попавшее в промт название вполне может появиться на вывеске.

### Две версии подряд

1. **Русская версия — для вычитки.** Те же блоки в том же порядке, что английская, чтобы сверять блок к блоку. Пометь как черновик.
2. **Английская версия — для вставки.** Один блок кода, внутри только промт. Под блоком строка из скрипта: `Символов: XXXX`.

**Почему английский.** Все примеры официального гайда на английском. В API английского текста помещается 26 000 символов, остальных языков — 11 000 (лимит считается в токенах, английский компактнее для токенизатора). Официальной рекомендации «китайский лучше» нет — в отличие от Seedance, переводить на китайский не нужно.

**Что остаётся на исходном языке:** реплики. Гайд: «To generate speech in a specific language, write the dialogue in that language inside quotation marks». Реплика по-русски пишется кириллицей в кавычках “…”, и больше кириллицы в английской версии нет нигде.

### Проверка скриптом

Сохрани английскую версию в файл и прогони:

```
python3 scripts/check_prompt.py prompt.txt --duration 25
```

Скрипт проверяет: длину (символы и примерные токены); кириллицу только внутри реплик в кавычках; биты в `ACTION TIMING` идут подряд без дыр и закрывают весь ролик; в каждом бите есть `CAMERA:` перед `ACTION:` и есть `ACTING:`, записанный телом; каждый `@ImageN`/`@VideoN` объявлен в `ACTIVE REFERENCES` и у каждого написано, что не брать; нет абстракций («stunning», «cinematic feel»); есть «no background music» (флаг `--music`, если музыка нужна) и «no subtitles»; не слишком много запретов; сказано, один дубль или склейки; нет слов о процессе. Выдавай только промт, прошедший проверку.

---

## СТРУКТУРА ПРОМТА

Короткая официальная схема для Omni Reference:

```
[Asset Roles]      @Image1 defines ___; preserve its ___. Reference the ___ of @Video1.
[Overall Settings] Scene and texture: ___; visual style: ___; camera tone: ___.
[Sequence of Events]
0–X s: ___ (visuals + action + emotion)
X–Y s: ___ (camera movement + additional details)
Y s–end: ___ (closing shot)
[Audio]            Dialogue/voiceover + ambient sounds + music + sound effects
```

Для роликов длиннее 10 секунд и сложных сцен — **15-блочная схема из длинных официальных примеров**, наш рабочий формат. Блоки нумеруются и пишутся КАПСОМ с двоеточием:

| № | Блок | Что внутри |
|---|---|---|
| 1 | `SCENE CONTEXT` | счёт персонажей капсом («EXACTLY 2 MAIN CHARACTERS — NO DUPLICATES»), длительность, формат, жанр, сюжет в 3–5 предложениях |
| 2 | `ACTIVE REFERENCES` | роль каждого файла: что берём, что сохранить, что не брать |
| 3 | `LOCATION MAP` | где что стоит, куда смотрит, направление движения, с какой стороны камера |
| 4 | `CHARACTERS` | внешность и одежда каждого героя, характер; машина/объект с ориентацией |
| 5 | `FORMAT MODE` | один дубль или N шотов с таймкодами склеек; смена скорости |
| 6 | `OPTICS` | фокусные (мм, можно FOV в градусах), глубина резкости |
| 7 | `CAMERA` | характер камеры: дрон, стедикам, ручная SETTLE, тряска или нет |
| 8 | `ACTION TIMING` | биты: таймкод → `CAMERA:` → `ACTION:` → `ACTING:` → `DIALOGUE:` |
| 9 | `PHYSICS` | вес, инерция, как ведут себя стекло, ткань, огонь, жидкость |
| 10 | `LIGHTING` | один мотивированный источник и куда падают отсветы |
| 11 | `AUDIO` | звук по таймкодам, реплики, «No background music» |
| 12 | `STYLE` | плёнка/цифра, грейд, зерно, палитра в процентах (60/30/10) |
| 13 | `QUALITY` | что должно остаться одинаковым: лица, одежда, геометрия объекта, пальцы |
| 14 | `POSITIVE CONSTRAINTS` | что обязано быть в кадре, позитивно; «No subtitles, no on-screen text» |

Официальные примеры ещё используют `FIRST FRAME AND SPATIAL BLOCKING` (первый кадр и расстановка) — добавляй, если важен стартовый кадр.

Обязательные блоки: `SCENE CONTEXT`, `ACTION TIMING`, `AUDIO`, `POSITIVE CONSTRAINTS`, и `ACTIVE REFERENCES`, если есть файлы.

### Бит раскадровки

```
6–12s
CAMERA: Outside the car, 1.7 m high, facing the rear-right window, slow push-in from 1.3 m to 1 m, 24mm, focus on Alice's face.
ACTION: Still slow motion, shards drift past outside the window.
ACTING: Alice leans back relaxed, legs crossed, one hand on the armrest, head turned to the camera; bored half-smile, one eyebrow slightly raised. She talks at a normal pace, casually; on the word “просто” she gives a lazy wave of her hand.
DIALOGUE: Alice says in Russian: “Такие видео делать очень просто…”
```

---

## ОДИН ДУБЛЬ ИЛИ МУЛЬТИ-ШОТ

**Мульти-шот в Kling 4.0 включён по умолчанию и не выключается тумблером** («Smart Storyboard… enabled by default and have no separate toggles»): модель сама режет ролик на планы, если не сказать иначе.

- **Один дубль** — пиши в `FORMAT MODE` прямо, как в официальном примере: «The entire sequence must be one continuous master shot with no visible cuts». И в каждом следующем бите: `CAMERA: The same shot continues. …`. Все смены крупности — движением камеры.
- **Склейки** — перечисли шоты с таймкодами: `SHOT 1 — 0.0–4.0s: roar and launch.` и чем мотивирована склейка («cuts are motivated by wing wipes, smoke wipes and close architectural passes»). Без склеек-наплывов: «No fades or dissolves».
- **Монтажная сцена в одном ролике** работает: в официальном примере «00:00–00:03 | Five Rapid Cuts» — пять планов за три секунды.

## ТАЙМКОДЫ

- Биты идут подряд без дыр и закрывают весь ролик.
- **Дробные секунды можно** — в отличие от Seedance. Официальные примеры: `0.0–0.8s`, `13.5–15.0s`, реплика на `0.78s`. Но не дроби без нужды: для драматургии 2–4 секунды на бит.
- Смена скорости пишется прямо, с границами: «Slow motion from the window impact until 12s. At 12s time snaps back to real time». Нужна обычная скорость весь ролик — «real time, no slow motion, no speed ramps».

---

## ЗВУК И РЕПЛИКИ

- **Звук генерируется всегда**, выключателя нет ни на сайте, ни в API 4.0, ни на Higgsfield. Нужна тишина или свой звук — опиши звук в `AUDIO` и замени дорожку на монтаже.
- **Музыку модель добавляет по умолчанию.** Не нужна — «No background music, no score, no song» (официально: «SFX only, no music, no score, no song, no soundtrack»).
- **Загрузить музыку или SFX нельзя.** Аудио на вход — только голосовой профиль (до 3 на задачу, исходник 5–30 с).
- **Языки речи официально:** китайский, английский, японский, корейский, испанский, португальский, немецкий, французский, хинди; диалекты и акценты. **Русского в списке нет.** Если герой говорит по-русски — пиши реплику по-русски в кавычках, губы будут двигаться, но произношение не гарантировано; надёжнее записать голос и положить поверх на монтаже. В промте о переозвучке ни слова.
- **Голос описывай:** возраст, тембр, темп, эмоция, на каких словах ударение — «She speaks in natural, clear, slightly slow Spanish: "…"».
- **Несколько говорящих** — правила в `AUDIO`: «Each person has a distinct voice. When one person is speaking, the others remain silent. No interruptions or overlapping dialogue.»
- **Текст реплики — один раз**, в бите, где она звучит. Длину бита считай по фразе: примерно 2–2,5 слова в секунду.

---

## ПРЕВИЗ ИЗ BLENDER (WHITE-MODEL) И ВИДЕО-РЕФЕРЕНС

**Официально:** «White-model and depth-map videos are also supported, giving you more precise control over motion, camera movement, and timing» (страница релиза для разработчиков, пресс-релиз 16.10.2026). Серая или цветная болванка из Blender — штатный вход Kling 4.0.

**Требования к видео (API, жёстко):**
- каждая сторона **не меньше 700 px** (до 4553), площадь не больше 8 294 400 px — превиз 640×480 не пройдёт, рендерь 960×720 или увеличь ffmpeg (`scale=960:720:flags=lanczos`);
- 3–30 с каждое, все видео в сумме ≤ 30 с, до 5 штук, ≤ 300 МБ, mp4/mov;
- 24–60 к/с на входе, на выходе всегда 24;
- соотношение сторон от 2:5 до 5:2.

**Как писать роль превиза:**
```
@Video1 is a colored white-model blocking animation of this exact shot, with no sound.
It is a moving blueprint and controls only the motion: the camera's path, height,
framing and lens changes, the timing and speed changes, and the positions and paths of
the car and the people. Follow it frame by frame. Its pink figure becomes Alice from
@Image4, its light-blue figure becomes the driver from @Image5, its black box car
becomes the car from @Image3, its room becomes the hall from @Image1, its other
cylinders become casino guests. Do not take its flat untextured shapes, primitive
geometry, colors or lighting.
```
Каждая болванка названа тем, во что превращается, со ссылкой на её карточку, — иначе модель не знает, какая болванка кто. Болванка без лица и рук: игру пиши в `ACTING` каждого бита, иначе персонаж повторит болванку буквально. Ориентацию движущегося объекта фиксируй в `LOCATION MAP` словами «This never changes».

**Референс или редактирование.** У Kling два разных входа для видео:
- **референс** (`feature_video`, на Higgsfield — режим `reference-to-video`, роль `video_references`): берёт из видео то, что сказано в роли, — камеру, движение, тайминг. Для превиза — этот.
- **редактирование** (`base_video`, режим `video-edit`): меняет само видео. Промт обязательно начинается с «Edit @Video1», и «Keep everything else unchanged». Гайд: «Simply writing "Reference @Video1" may be interpreted as reference-based generation instead of editing».

Чем точнее Kling держит траекторию превиза в сравнении с Seedance — **см. раздел «Проверено на тестах»**: официальных обещаний покадровой точности нет.

---

## ФОРМАТ КАДРА

Выход: **21:9, 16:9, 1:1, 9:16, Auto.** **4:3 и 3:4 в списке нет.**
- Auto (в API `adaptive`): сначала ищет формат в тексте промта («Generate a 9:16 vertical video»), потом берёт у видео для редактирования, ключевых кадров, других входных видео; если ничего нет — 16:9.
- Нужен 4:3 — ставь Auto, пиши «horizontal 4:3» в `SCENE CONTEXT` и подавай превиз 4:3. Вышло 16:9 — режь на монтаже или делай превиз сразу в 16:9.

---

## ЛИМИТЫ

| Параметр | Kling 4.0 | Kling 4.0 Flash |
|---|---|---|
| Длительность | 3–30 с, шаг 1 с, по умолчанию 10 | 3–20 с |
| Разрешение | сайт 720p / 1080p / 4K; API и Higgsfield 720p / 1080p | 720p |
| HDR 10 бит (1080p, 4K) | «coming soon» | нет |
| Кадров в секунду | 24 | 24 |
| Формат | 21:9 / 16:9 / 1:1 / 9:16 / Auto | те же |
| Промт | сайт до 8000 токенов; API: английский до 26 000 символов, другие языки до 11 000 | — |
| Картинки | до 10; ≤ 30 МБ; jpg/png; сторона ≥ 300 px; 2:5–5:2 | — |
| Видео | до 5; 3–30 с; в сумме ≤ 30 с; сторона 700–4553 px; ≤ 300 МБ | — |
| Элементы | до 7, из них видео-элементов до 3 | — |
| Голосовые профили | до 3, исходник 5–30 с, ≤ 50 МБ | — |
| Всего файлов | ≤ 15 | — |
| Ключевые кадры | до 10, в любом месте таймлайна (только вход Keyframes) | нет |
| Продление | до 2 минут — «coming soon» | — |
| Звук | стерео, всегда включён | — |

**Два входа на сайте не смешиваются:** Omni Reference (картинки, видео, голоса, элементы; там же текст-в-видео и первый кадр + видео) и Keyframes (только картинки-кадры, пиксельная точность кадров). «The Keyframes entry does not support uploading reference assets».

---

## ГДЕ ЗАПУСКАТЬ

**kling.ai** — Omni Reference и Keyframes, 4K, все лимиты гайда.

**Higgsfield** — модель `kling4_0`:
- режимы `text-to-video`, `image-to-video`, `reference-to-video`, `video-edit`;
- роли файлов: `start_image`, `end_image`, `image_references`, `video_references`; `kling_element_ids` до 7;
- 720p / 1080p, 3–30 с, форматы 21:9 / 16:9 / 9:16 / 1:1 / auto;
- нумерация `@Image1…` — в порядке картинок в `medias`, `@Video1` — первое видео;
- цена по `get_cost` на 24.10.2026: 25 с в 1080p — 25 кредитов, в 720p — 12,5 (с видео-референсом так же). Для сравнения Seedance 2.5 в 1080p на 25 с — 400. Цену проверяй `get_cost` перед запуском: на старте модели она может быть акционной.

**fal** — `kling/v4/reference-to-video` и другие: `@Image1`, `@Video1`, `@Element1`; есть `multi_prompt` — список шотов по ≤ 512 символов с длительностью у каждого.

**Официальный API** — `/omni-video/kling-4.0`, файлы в массиве `contents` с типами `first_frame`, `middle_frame`, `last_frame`, `refer_image`, `feature_video`, `base_video`, `element`, `voice`; ссылка на файл — по его `id` (`@image_1`). Цена: без видео на входе 720p $0.157/с, 1080p $0.235/с; с видео на входе $0.094 / $0.141 за секунду, но считается минимум 2× длительность выхода.

---

## РЕДАКТИРОВАНИЕ, ПЕРЕСЪЁМКА, КЛЮЧЕВЫЕ КАДРЫ

**Редактирование** — до 5 клипов, из них 1 основной. Формула: «Edit @Video1. Change … to …. Keep everything else unchanged: [перечисли поимённо — фон, камера, свет, длительность, звук]».

| Задача | Официальный пример |
|---|---|
| Добавить | Edit @Video1. When the box is opened again at the end, add @Element1 lying inside asleep. |
| Заменить героев и среду | Edit @Video1. Replace the environment and characters throughout with those in @Image1. |
| Убрать | Remove the person in the foreground from @Video1. Keep everything else unchanged. |
| Стиль | Edit @Video1. Replace the corgi with a 3D pixel-art corgi while preserving its actions. |

Стилизация: при анимационном стиле прямо исключай фотореализм — иначе стили смешаются.

**Пересъёмка чужого ролика (Creative Recreation):** «Replace the element in @Video1 with @Image1. Keep everything else unchanged». Чем ближе темп и структура референса к задуманному, тем точнее.

**Ключевые кадры** (отдельный вход, без референсов): «Use @Image1 as the first frame…», «…and @Image2 as the last frame…», промежуточные — `X–Y sec | Keyframe 1: [что происходит и как камера туда приходит]`. Формат кадра берётся у первого ключевого кадра.

---

## ЧТО ГОВОРЯТ КРЕАТОРЫ (первые 9 дней после релиза)

Модели на момент сборки скилла 9 дней, тестов мало, часть авторов — партнёры Kling или площадок. Единичный отзыв помечен.

### Сильные стороны
- **Слушается режиссуры.** Чаще других выполняет заданные биты по порядку и мелкие детали («кружка ручкой влево, ровно три книги»). В сравнении четырёх моделей — лучший для точных движений камеры и длинного плана с одним движением.
- **Держит референсы.** Лица, надписи на одежде и шлемах, машины по реф-картам — в тесте с превизом только Kling сохранил обе машины как на картинках.
- **Руки и посадка за рулём** исправлены по сравнению с 3.0: водитель слева, руки на руле, по пять пальцев.
- **Липсинк** сильно лучше 3.0, губы попадают в слова. Русский липсинк на Flash хвалят (единичный отзыв), хотя русского нет в официальном списке.
- **Видео-референс камеры** — один из лучших: лучше MiniMax, примерно на уровне Seedance 2.0.
- **Промежуточные ключевые кадры** — то, чего нет у Seedance: историю можно провести через точку в середине.
- **Стили** держатся от первого до последнего кадра, нуар особенно хорош. Крупный текст в кадре читается, мелкий плывёт.
- **Цена** в 2,5–11 раз ниже Seedance 2.5 в зависимости от площадки.

### Слабые стороны
- **Реализм и физика слабее Seedance 2.5.** Кожа «пластиковая» на крупных планах, вода не похожа на воду, стекло бьётся одинаковыми треугольниками, капли — идеальные шары.
- **Контактный экшн.** Удары зависают в воздухе позой, падения мультяшные, ступни скользят. Драки и столкновения расписывай с весом и реакцией на каждый удар, а лучше отдавай Seedance.
- **Длинный дубль сыпется после ~15 секунд**: появляется лишний план, реплики сливаются. В тесте на 30 с годных вышло около 9 с против 29 у Seedance 2.5 (один тест). Если дубль сыпется — два прохода по 15 с или ключевые кадры в середине.
- **Додумывает лишнее.** Дорисовывает объекты и людей, чтобы «объяснить» картинку: на кадре был всплеск — появился ребёнок, который его поднял; у героя возник пиджак, которого не было. Лечится точным счётом в `SCENE CONTEXT` и `POSITIVE CONSTRAINTS`.
- **Эмоции сдержаннее**, чем у Seedance («the most restrained», «a bit flat»). Игру в `ACTING` пиши крупнее, чем для Seedance.
- **Задом наперёд.** Машина, которая «смотрит вперёд и едет назад», встречалась (единичный отзыв, без превиза). Ориентацию фиксируй всегда.
- **Звук.** Готовый аудиофайл для липсинка не загрузить — только образец голоса от 5 с. Без голосового профиля речь иногда звучит на непонятном языке; реплика может обрезаться в конце клипа. Flash иногда добавляет музыку без запроса.
- **Медленный рендер:** 3–6 минут на клип 8 с.

### Приёмы, которые работают
- **Превиз — «движущийся чертёж».** Рабочая формулировка из открытого теста с превизом из Blender (все три модели пошли за превизом):
  ```
  @Video1 is a grey 3D previs animation of this exact scene, made in Blender,
  with no sound. It controls the motion and only the motion: every car's path,
  speed, order and swerve, the camera's positions, heights, lenses and moves,
  and the two hard cuts at 0:04 and 0:07. Follow it frame by frame. It is a
  moving blueprint: its grey blocks become the real channel of @Image1,
  its black block becomes the car of @Image2…
  ```
  То есть: роль превиза — только движение; «follow it frame by frame»; **каждая болванка названа тем, во что превращается**. Официальная формулировка fal: «Preserve the movement and camera timing of the supplied white-model video, replacing the unfinished surfaces with the appearance established by the images».
- **Ориентация словами «This never changes».** «Both cars drive forward, nose first… always travel from FRAME-LEFT toward FRAME-RIGHT. This never changes.»
- **Называй каждого персонажа в каждом бите.** В тесте первый план не назвал водителя — машина четыре секунды ехала сама.
- **Блок `LOCKS:`** вместо негатива — утверждения с точным счётом: «EXACTLY TWO fighters. The crowd keeps to the edges and never joins in.» У нас это `POSITIVE CONSTRAINTS`.
- **`FRAME LOCK`** против сетки и сплит-скрина, когда среди референсов есть доски 2×2: «one photographic 16:9 frame filling the screen edge to edge at every moment. Never divided, never a grid.»
- **Короткий чистый референс копируется лучше**: обрезай видео-референс до нужного куска, роль — «camera moves, timing and cuts».
- **Ключевые кадры внутри Omni Reference.** Официально входы не смешиваются, но картинки в Omni можно описать текстом как кадры на таймкодах: «@image1… are keyframes… @image1 at 0:04, @image2 at 0:06…». В тесте годных секунд стало 11–12 вместо 8–9.
- **Keyframes против Omni:** «Keyframes follows your pictures, the prompt is just direction. Omni follows your prompt, the pictures are just direction». Omni реалистичнее; кадры Keyframes смотрятся вклеенными. 5 ключевых кадров на 30 с сработали лучше, чем 10.
- **Сложный диалог** — два прохода по 15 с вместо одного на 30.

### Модерация
Непредсказуемая и расходится между авторами: известные люди и персонажи иногда отклоняются, иногда проходят там, где Seedance отказывал; жёсткое насилие проходит; политика блокируется.

### JSON или текст

- **Официально JSON нигде не упоминается** — ни в гайде 4.0, ни в гайде 3.0 Omni, ни в общем prompt guide Kling. Все примеры — размеченный текст: блоки КАПСОМ или в квадратных скобках с прозой внутри. «JSON» в документации API — это тело запроса, а само поле `prompt` в нём — обычная строка; JSON внутри неё модель читает просто как слова.
- **Независимые тестеры 4.0 пишут размеченным текстом**, а не JSON.
- **Публичного A/B на 4.0 нет.** Отзывы «JSON лучше» — на Kling 2.6, по одному-два прогона, от авторов, которые продают генераторы JSON-промтов.
- **Наш A/B (24.10.2026, превиз 25 с, по одному прогону):** тот же промт в JSON прошёл превиз по всем битам, текстовый сломал сюжет после 12 с (подробно — «Проверено на тестах»). Один прогон — не доказательство: разница может быть сидом.
- **Пока нет повторного теста:** для сцены с превизом и многими битами выдавай обе формы — размеченный текст и JSON с тем же содержанием (ключи `scene_context`, `active_references`, `location_map`, `characters`, `format_mode`, `optics`, `camera`, `action_timing` — список битов `{time, camera, action, acting, dialogue}`, `physics`, `lighting`, `audio`, `style`, `quality`, `positive_constraints`). JSON собирай кодом из текстовой версии (`json.dumps(..., ensure_ascii=False, indent=2)`), чтобы содержание совпало слово в слово; реплики в “…” или «…», прямые кавычки внутри строк не ставить.


---

## ПРОВЕРЕНО НА ТЕСТАХ PROF AI

| Что проверяли | Результат |
|---|---|
| Превиз 640×480 как видео-референс | Не пройдёт по лимиту 700 px: увеличили ffmpeg до 960×720, Higgsfield принял |
| Цена на Higgsfield, 25 с, превиз + 6 картинок | 25 кредитов в 1080p, 12,5 в 720p (`get_cost`, 24.10.2026) |
| Формат 4:3 через Auto + «horizontal 4:3» в тексте + превиз 4:3 | Работает: вышло 1660×1244, 24 к/с, 25,04 с, стерео |
| Превиз-болванка 25 с, один дубль, 10 битов, `reference-to-video` | В варианте JSON модель прошла превиз по битам: водитель → Алиса в заднем окне → машина в зале сзади → вылет через окно → Алиса у стены → граната → огненный шар на 24 с. В текстовом варианте после 12 с сюжет сломался: машина оказалась на улице перед фасадом, водитель пересел к Алисе назад, взрыва нет. Один прогон на вариант — разница может быть случайностью сида |
| Русские реплики в кавычках | Произнесены по-русски, whisper распознал обе фразы; «PROF AI Club» исковеркан. Голос всё равно кладём поверх |
| Текст в кадре | Модель сама добавила вывеску «Casino» и номер с абракадаброй — пиши «blank license plates, no signs with letters» в `POSITIVE CONSTRAINTS` |
| Время рендера | ~16 минут на 25 с в 1080p |


---

## ТИПОВЫЕ ОШИБКИ И РЕШЕНИЯ

| Проблема | Решение |
|---|---|
| Модель сама порезала ролик на планы | «The entire sequence must be one continuous master shot with no visible cuts» + «The same shot continues» в каждом бите |
| В ролике музыка | «No background music, no score, no song» в `AUDIO` |
| Появились субтитры | «No subtitles, no on-screen text» в `POSITIVE CONSTRAINTS` |
| Файл использован не так | роль каждому `@`: что берём, что сохранить, что не брать |
| Фон реф-карты в окнах | «Do not take the background behind its windows» в роли карточки |
| Персонаж окаменел как на карточке | «do not take the pose and the facial expression» + `ACTING` в каждом бите |
| Видео-референс не принят | сторона меньше 700 px или длина меньше 3 с — увеличь превиз, проверь сумму видео ≤ 30 с |
| Вышло 16:9 вместо 4:3 | 4:3 нет в списке форматов: Auto + «horizontal 4:3» в тексте + превиз 4:3, иначе резать на монтаже |
| Вместо правки — новый ролик | «Edit @Video1», а не «Reference @Video1» |
| Абстрактный результат | заменить «premium», «cinematic» на свет, материал, композицию |
| Русская речь с акцентом или мимо | русского нет в списке языков: записать голос и положить поверх; реплику в кавычках оставить для губ |
| Слишком много «no/avoid» | переписать в `POSITIVE CONSTRAINTS` позитивно, оставить «no subtitles» и «no music» |

---

## ЧЕКЛИСТ ПЕРЕД ВЫДАЧЕЙ

1. Каждому `@ImageN` / `@VideoN` написана роль: что берём, что сохранить, что НЕ брать?
2. В `SCENE CONTEXT` счёт персонажей капсом, длительность, формат, жанр?
3. В каждом бите `CAMERA:` первым: точка, высота, угол, мм, фокус, движение путём?
4. В каждом бите `ACTING:` про каждого персонажа — поза, действие, эмоция телом, манера речи?
5. Биты идут подряд без дыр и закрывают весь ролик?
6. Сказано, один дубль или склейки?
7. Смена скорости названа с границами?
8. Реплика на нужном языке в кавычках, один раз, в своём бите? Русская — с пометкой пользователю, что голос лучше положить поверх?
9. В `AUDIO` есть «No background music», если музыку не просили? В `POSITIVE CONSTRAINTS` — «No subtitles»?
10. Запреты переписаны позитивно, абстракции заменены визуальными фактами?
11. Нет названий брендов и студий там, где они не нужны в кадре; нет слов о процессе?
12. Превиз ≥ 700 px по каждой стороне, видео в сумме ≤ 30 с?
13. Английская версия прошла `check_prompt.py`, длина из скрипта?
14. Выданы обе версии, стоит подпись «Промт по скиллу PROF AI · Kling 4.0» перед русской и её нет внутри промта?
15. Указан порядок загрузки файлов и настройки: режим, длительность, разрешение, формат, цена по `get_cost`?
