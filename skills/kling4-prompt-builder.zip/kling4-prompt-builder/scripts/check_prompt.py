#!/usr/bin/env python3
"""Проверка английской версии промта Kling 4.0 перед выдачей.

Запуск:
    python3 scripts/check_prompt.py prompt.txt
    python3 scripts/check_prompt.py prompt.txt --duration 25
    python3 scripts/check_prompt.py prompt.txt --music      # музыка в ролике нужна

Что проверяет:
- длину: до 8000 токенов на kling.ai (оценка), 26 000 символов английского в API;
- кириллица только внутри реплик в кавычках “…”, "…" или «…» (речь на нужном языке);
- раскадровка (блок ACTION TIMING): биты вида «0–3s» идут подряд без дыр и закрывают весь ролик;
- в каждом бите есть CAMERA: и он стоит перед ACTION:, есть ACTING:, и игра записана телом;
- каждый @ImageN / @VideoN / @ElementN, который встречается в тексте, объявлен в ACTIVE REFERENCES,
  и у каждого объявленного написано, что из него НЕ брать;
- нет абстрактных слов-похвал вместо визуальных фактов;
- запретов немного: официальный гайд просит только no subtitles и no background music;
- если склеек нет — прямо сказано, что ролик одним дублем (мульти-шот в 4.0 включён по умолчанию);
- нет слов о процессе и инструкций модели.

Код выхода 1, если есть ошибки.
"""
import argparse
import re
import sys

API_LIMIT = 26000          # символов английского текста в API
TOKEN_LIMIT = 8000         # токенов на kling.ai
CYRILLIC_RE = re.compile(r"[А-Яа-яЁё]")
QUOTED_RE = re.compile(r"“[^”]*”|\"[^\"]*\"|«[^»]*»")
BEAT_RE = re.compile(r"^\s*(\d+(?:\.\d+)?)\s*(?:s|sec)?\s*[–—-]\s*(\d+(?:\.\d+)?)\s*(?:s|sec)\b", re.M)
SECTION_RE = re.compile(r"^\s*(?:\d+\.\s*)?([A-Z][A-Z &/]+?)\s*:", re.M)
REF_RE = re.compile(r"@(Image|Video|Element)\s?(\d+)")
DURATION_RE = re.compile(r"(\d+)[- ]second")
ABSTRACT = ("cinematic feel", "premium look", "stunning", "epic", "masterpiece", "breathtaking",
            "beautiful", "high quality", "best quality", "ultra detailed", "8k", "award-winning",
            "gorgeous", "amazing", "perfect")
META_RE = re.compile(r"\b(will be dubbed|dubbing|voice will be replaced|replaced in post|for the lesson|"
                     r"this prompt|the model must|follow the storyboard strictly|priority)\b", re.I)
NEG_RE = re.compile(r"\b(no|not|never|don't|do not|avoid|without)\b", re.I)
BODY_MARKS = ("brow", "eye", "mouth", "lip", "jaw", "cheek", "nose", "face", "hand", "finger", "fist", "arm",
              "shoulder", "head", "chin", "neck", "chest", "leg", "knee", "foot", "feet", "lean", "slump",
              "sit", "stand", "crouch", "turn", "nod", "shrug", "wink", "smile", "smirk", "scream", "grip",
              "voice", "speaks", "says", "whisper", "shout", "tone", "pace", "breath", "thumb", "hair", "look",
              "gaze", "walk", "step", "run", "jump", "fall", "stumble", "duck", "toss", "throw", "push", "pull",
              "wave", "point", "body", "back", "hip", "wrist", "blink")
NO_PEOPLE = ("no people", "no one in frame", "nobody in frame", "no characters in frame")


def sections(text):
    """Блоки промта по заголовкам КАПСОМ: {имя: текст}."""
    found = list(SECTION_RE.finditer(text))
    out = {}
    for i, m in enumerate(found):
        name = m[1].strip()
        if name in ("CAMERA", "ACTION", "ACTING", "DIALOGUE"):
            continue                                   # поля внутри бита, не блоки
        end = len(text)
        for nxt in found[i + 1:]:
            if nxt[1].strip() not in ("CAMERA", "ACTION", "ACTING", "DIALOGUE"):
                end = nxt.start()
                break
        out[name] = text[m.end():end]
    return out


def check_beats(timing, duration, errors, warnings):
    beats = list(BEAT_RE.finditer(timing))
    if not beats:
        errors.append("ACTION TIMING: нет битов вида «0–3s» — раскадровка по времени обязательна")
        return
    prev_end = 0.0
    for i, m in enumerate(beats):
        start, end = float(m[1]), float(m[2])
        label = f"бит {m[1]}–{m[2]}s"
        if end <= start:
            errors.append(f"{label}: конец не позже начала")
        if abs(start - prev_end) > 1e-6:
            errors.append(f"{label}: начинается с {start:g}s, а предыдущий кончился на {prev_end:g}s")
        prev_end = end
        body = timing[m.end(): beats[i + 1].start() if i + 1 < len(beats) else len(timing)]
        cam, act, acting = body.find("CAMERA:"), body.find("ACTION:"), body.find("ACTING:")
        if cam < 0:
            errors.append(f"{label}: нет CAMERA: — ракурс первым в каждом бите")
        elif 0 <= act < cam:
            errors.append(f"{label}: CAMERA: должен стоять перед ACTION:")
        if acting < 0:
            errors.append(f"{label}: нет ACTING: — игра каждого персонажа; кадр без людей — «ACTING: no people in frame.»")
            continue
        acting_text = body[acting:].split("DIALOGUE:")[0].lower()
        if any(p in acting_text for p in NO_PEOPLE):
            continue
        marks = {b for b in BODY_MARKS if b in acting_text}
        if len(marks) < 2:
            errors.append(f"{label}: ACTING записан словом, а не телом — нужны поза, лицо (брови, глаза, рот), руки")
        elif len(marks) < 4:
            warnings.append(f"{label}: ACTING скупо ({len(marks)} признака тела) — добавь лицо, руки, корпус")
    if duration and abs(prev_end - duration) > 1e-6:
        errors.append(f"раскадровка кончается на {prev_end:g}s, а ролик {duration}s")


def main():
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("path", help="файл с английским промтом или - для stdin")
    parser.add_argument("--duration", type=float, help="длительность ролика в секундах")
    parser.add_argument("--music", action="store_true", help="музыка в ролике нужна")
    args = parser.parse_args()

    text = (sys.stdin.read() if args.path == "-" else open(args.path, encoding="utf-8").read()).strip()
    errors, warnings = [], []
    blocks = sections(text)

    # длина
    tokens = round(len(text) / 4)
    print(f"Символов: {len(text)} (API: до {API_LIMIT}), токенов примерно: {tokens} (kling.ai: до {TOKEN_LIMIT})")
    if len(text) > API_LIMIT:
        errors.append(f"больше {API_LIMIT} символов — API не примет")
    if tokens > TOKEN_LIMIT:
        errors.append(f"около {tokens} токенов — больше {TOKEN_LIMIT}, сайт не примет")

    # кириллица только в репликах
    probe = QUOTED_RE.sub("", text)
    for m in CYRILLIC_RE.finditer(probe):
        errors.append(f"кириллица вне реплики в кавычках — …{probe[max(0, m.start() - 15):m.start() + 20]!r}")
        break

    # раскадровка
    duration = args.duration
    if duration is None:
        m = DURATION_RE.search(blocks.get("SCENE CONTEXT", text[:400]))
        duration = float(m[1]) if m else None
    timing = blocks.get("ACTION TIMING")
    if timing is None:
        errors.append("нет блока ACTION TIMING")
    else:
        check_beats(timing, duration, errors, warnings)

    # референсы
    refs_block = blocks.get("ACTIVE REFERENCES", "")
    used = {f"@{k}{n}" for k, n in REF_RE.findall(text)}
    declared = {f"@{k}{n}" for k, n in REF_RE.findall(refs_block)}
    for ref in sorted(used - declared):
        errors.append(f"{ref} встречается в тексте, но не объявлен в ACTIVE REFERENCES — роль обязательна")
    for line in refs_block.splitlines():
        ids = REF_RE.findall(line)
        if ids and not NEG_RE.search(line) and "only" not in line.lower():
            warnings.append(f"ACTIVE REFERENCES: у «{line.strip()[:50]}…» не написано, что НЕ брать")
    if used and not refs_block:
        errors.append("есть @-референсы, но нет блока ACTIVE REFERENCES")

    # абстракции и процесс
    low = text.lower()
    for word in ABSTRACT:
        if re.search(r"\b" + re.escape(word) + r"\b", low):
            warnings.append(f"абстрактное слово «{word}» — замени визуальным фактом (свет, материал, композиция)")
    meta = META_RE.search(text)
    if meta:
        errors.append(f"инструкция или процесс вместо описания ролика — «{meta[0]}»")

    # запреты
    if "subtitle" not in low:
        warnings.append("нет «no subtitles» — модель может добавить субтитры сама")
    if not args.music and not re.search(r"no (background )?music|no score|no soundtrack", low):
        errors.append("нет «no background music» — музыку модель добавляет по умолчанию")
    rest = QUOTED_RE.sub("", text)
    negs = len(NEG_RE.findall(rest))
    if negs > 25:
        warnings.append(f"запретов много ({negs}) — гайд Kling: негативы повышают риск ошибок, переформулируй позитивно")

    # один дубль или склейки
    if not re.search(r"cut|continuous|one take|single take|oner|master shot", low):
        warnings.append("не сказано, есть ли склейки: мульти-шот включён по умолчанию — "
                        "для одного дубля пиши «one continuous shot with no cuts»")

    for w in warnings:
        print(f"предупреждение: {w}")
    for e in errors:
        print(f"ОШИБКА: {e}")
    if errors:
        sys.exit(1)
    print("OK — ошибок нет")


if __name__ == "__main__":
    main()
