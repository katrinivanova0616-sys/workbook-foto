# Банк стилей: термины, которые реально работают

Готовые формулировки для сборки визуального языка кадра. Бери по одному термину из нужной категории, не стакай противоречивые.

## Содержание
- [Объективы и диафрагма](#объективы-и-диафрагма)
- [Плёнка](#плёнка)
- [Свет](#свет)
- [Композиция и ракурс](#композиция-и-ракурс)
- [Планы](#планы)
- [Медиумы и стили](#медиумы-и-стили)
- [Готовые связки под задачи](#готовые-связки-под-задачи)

## Объективы и диафрагма

| Термин | Что даёт |
|---|---|
| 14-16mm ultra-wide | драматичная перспектива, искажение краёв |
| 24mm | ландшафт, архитектура |
| 35mm | стрит, environmental portrait |
| 50mm | натуральная перспектива, как глаз |
| 85mm | портрет, сжатие фона |
| 100mm macro | фактура, детали |
| 135mm | короткий телевик |
| 200mm+ telephoto | сильное сжатие, плотное боке |
| fisheye lens | круговое искажение |

Диафрагма: `f/1.4`-`f/2.8` малая ГРИП и боке, `f/8` максимальная резкость, `f/16` глубокая резкость по всему кадру.
Дополнительно: `bokeh`, `shallow depth of field`, `deep focus`.

## Плёнка

Ориентир по характеру, не точная калибровка.

| Плёнка | Характер |
|---|---|
| Kodak Portra 400 | тёплая кожа, портрет, мягкие тона |
| Kodak Portra 800 | теплее и зернистее |
| Kodak Ektar 100 | насыщенно, резко |
| Kodak Gold 200 | ностальгия, янтарь |
| Fujifilm Velvia 50 | гиперсатурация, ландшафт |
| Fujifilm Pro 400H | пастель, воздух |
| CineStill 800T | ночь, неон, halation вокруг источников света |
| CineStill 50D | дневной кинолук |
| Ilford HP5 / Kodak Tri-X | драматичный ЧБ, зерно |
| Polaroid | мгновенный, выцветший |

## Свет

**Время суток и погода:** golden hour, blue hour, overcast, soft diffused light, harsh midday sun, moonlight, window light, god rays.

**Портретные схемы:** Rembrandt lighting, butterfly lighting, loop lighting, split lighting, clamshell lighting, rim light, backlight, softbox, high-key, low-key, three-point lighting.

**Настроенческий свет:** chiaroscuro, volumetric lighting, neon lighting, practical lights, teal and orange grade.

Правило: один основной световой термин плюс один модификатор. Три световые схемы в одном промте гасят друг друга и дают кашу.

## Композиция и ракурс

**Композиция:** rule of thirds, leading lines, symmetry, negative space, framing, golden ratio.

**Ракурс:** low angle, high angle, eye-level, Dutch angle, bird's-eye view, aerial drone shot, over-the-shoulder, POV, profile view.

## Планы

extreme close-up, close-up, medium shot, full body shot, wide shot, long shot, establishing shot, panoramic.

## Медиумы и стили

**Традиционные:** oil painting, watercolor, sumi-e ink wash, pencil sketch, charcoal drawing.

**Фото и кино:** cinematic photography, photorealistic, DSLR photo, film noir, double exposure, documentary photography.

**Цифровые:** concept art, 3D render, octane render, unreal engine, isometric, pixel art, flat illustration, anime, manga (для аниме лучше `--niji 7`).

**Художественные направления:** ukiyo-e, art nouveau, art deco, bauhaus, cubism, pop art, surrealism, stained glass.

## Готовые связки под задачи

**Фэшн-эдиториал**
```
[субъект и одежда], [локация], editorial fashion photography, [свет],
full body shot, 85mm f/2, Kodak Portra 400 --ar 4:5 --s 250 --v 8.2
```

**Продуктовый шот**
```
[продукт] on [поверхность], studio product photography, softbox lighting,
seamless background, 100mm macro, f/8, sharp detail --ar 1:1 --s 50 --raw --v 8.2
```

**Кинокадр**
```
cinematic still of [сцена], [окружение], [время суток], volumetric lighting,
low angle, 35mm anamorphic, CineStill 800T, moody --ar 21:9 --s 200 --v 8.2
```

**Концепт-арт**
```
concept art of [объект], [окружение], dramatic rim light, wide establishing shot,
painterly, highly detailed --ar 16:9 --s 600 --v 8.2
```

**Портрет-референс для серии**
```
portrait of [подробное неизменное описание внешности], neutral background,
soft even lighting, eye-level, 85mm f/2 --ar 1:1 --s 100 --raw --seed [число] --v 8.2
```
Блок описания внешности в такой серии копируется дословно из кадра в кадр.
