---
name: cinematic-film-look
description: >-
  Инженер киношной картинки (film look) для AI-генераций. Используй этот скилл
  ВСЕГДА когда нужно сделать изображение или видео «киношным», «как в кино»,
  «как кадр из фильма», добавить плёнку/зерно/грейд, применить стиль
  триллера/нуара/драмы, починить пластиковую кожу или «мультяшность» в
  Seedance, подготовить референсы к видеогенерации, написать промт с цветокором
  teal & orange или эмуляцией киноплёнки Kodak. Триггеры — «киношный стиль»,
  «киношная картинка», «film look», «плёночный», «как в кино», «грейд»,
  «color grade», «в стиле триллера», «нуар», «пластиковая кожа», «мультяшно
  получается», «halation», «зерно».
---

# Cinematic Film Look — инженер киношной картинки

Скилл превращает любую AI-генерацию (фото и видео) в кадр, неотличимый от киноплёнки. Собран из проверенных в продакшене блоков: Weavy + GPT Image 2 + Seedance 2.0.

---

## ГЛАВНЫЕ ПРИНЦИПЫ — читать всегда

1. **Цифру выдаёт чистота.** Признаки плёнки: halation (тёплое свечение вокруг ярких источников), lifted blacks (молочные чёрные, ни одной чисто-чёрной точки), органическое зерно с неравномерным распределением (плотнее в тенях), мягкий roll-off светов, лёгкая мягкость оптики вместо цифрового шарпенинга.
2. **Конкретный киносток > слово «cinematic».** Модели знают цветовую науку реальных плёнок и симулируют фотохимию, а не вешают фильтр. Подбор стока — в `references/film-stocks.md`.
3. **Стиль без сцены = новая сцена.** Стилевой блок без SCENE LOCK заставляет модель сгенерировать новую картинку под mood (так появляются случайные «мужики в машинах»). В i2i всегда сначала SCENE LOCK, потом стиль.
4. **В i2i трансформация доминирует.** Если блок «Сохранить» жирнее блока «Изменить» — модель вернёт исходник без изменений. Команда трансформации — первой и с усилением (STRONG, clearly visible). Preserve — коротким хвостом.
5. **Противоречия убивают промт.** «clean sharp focus» + «slight softness» в одном промте = модель игнорирует оба. Перед выдачей проверь промт на взаимоисключающие команды.
6. **Картинка-референс бьёт текстовый стиль.** Если к генерации приложены чистые глянцевые рефы — модель сматчит их стиль и проигнорирует film look из текста. Два лекарства: (а) развести роли прямо в промте: «референсы только для идентичности лица/локации, стиль и грейд с референсов НЕ брать — стиль строго по описанию ниже»; (б) деграднуть сами рефы плёночным проходом.
7. **Киношность = на 90% световой рисунок, плёнка — приправа.** Если кадр «некиношный» при правильном зерне и грейде — проблема в свете: ровное многоисточниковое освещение (high-key) против низкого ключа. Лечится Шаблоном C, не добавкой зерна.
8. **Слишком чистые референсы = пластик в видео.** Стерильное изображение для видеомодели «вне распределения». Перед подачей в Seedance референсы слегка «загрязнять»: зерно, 5–10% мягкий блюр или плёночный грейд. Magnific/Skin Enhancer — только ПОСЛЕ видеогенерации, не до.

---

## РОУТИНГ

| Задача | Что делать |
|--------|-----------|
| Сделать готовый кадр киношным (i2i) | Шаблон A ниже |
| Сгенерировать киношный кадр с нуля (t2i) | Шаблон B + сток из `references/film-stocks.md` |
| Киношное видео в Seedance / пластиковая кожа | Читай `references/seedance-film.md` |
| Подобрать киносток под настроение (триллер, нуар, романтика...) | Читай `references/film-stocks.md` |

---

## ШАБЛОН A — i2i: плёночный грейд поверх готового кадра

Язык: английский (проверенные токены). Структура обязательна, порядок блоков не менять.

```
Use the attached image as the base. This is an image-to-image color grade and film emulation pass. Apply a STRONG, clearly visible cinematic transformation to the entire frame while keeping the scene itself untouched.

SCENE LOCK:
The scene is exactly what is in the attached image: [1–2 предложения — что на кадре: локация, персонажи, ключевые объекты]. Do not invent a new scene. Do not add new locations. Same composition, same camera angle, same people, same poses.

[СТОК И БАЗА — из film-stocks.md, по умолчанию:]
Teal & Orange style, muted tones, cinematic shot, film grain effect, realistic, Arri Alexa 35, f/4.

LIGHTING
• Mixed color temperature: warm highlights on skin, cool cyan / green shadows.
• Faces partially in shadow, sculpted by light.
• Uneven exposure, imperfect lighting falloff.
• Background slightly noisier than subjects.

FILM LOOK
• Real cinematic film still, not AI-clean.
• Organic film grain with uneven distribution, grain clumps slightly in shadows.
• Gentle halation and bloom on highlights — [перечислить яркие источники из кадра].
• Slight softness, imperfect focus lock. No digital sharpening.
• Muted saturation, lowered midtones, lifted milky blacks — no pure black anywhere in frame.

MOOD
[Одна строка под жанр: «Grounded crime thriller. Quiet danger. Control. Power.» / своё]

PRIORITY RULE
If any cinematic style conflicts with realism, realism wins. If any lighting conflicts with identity, identity wins. If any style conflicts with the attached base image content, the base image content wins — but the color grade and film texture must still be applied at full strength.

Constraints: no new objects, no new people, no scene changes, no logos, no text, no watermarks.
```

Запрещено добавлять в шаблон A: `clean sharp focus`, `4k ultra sharp`, `HDR` — конфликтуют с film look.

## ШАБЛОН B — t2i: запечь плёнку в генерацию с нуля

В обычный промт кадра (Subject + Action + Environment + Camera + Lighting) добавить в конец плёночный блок:

```
[Сток из film-stocks.md, например:] Kodak Vision3 500T color science, tungsten-balanced: warm amber from practical lamps, cool cyan-teal daylight spill. Green-cyan tint in shadows typical of scanned negative. Soft highlight roll-off — no blown whites. Gentle halation around bright light sources. Lifted milky blacks. Fine organic film grain, denser in shadows. Slight chromatic aberration at high-contrast edges near frame borders. Subtle vignette. Slight optical softness, no digital sharpening. Natural skin texture with visible pores and subtle oil, no plastic smoothing.
```

---

## ШАБЛОН C — LOW-KEY: киношный световой рисунок

Применять когда кадр «красивый, но не кино»: ровный свет, всё видно, пастель. Вставлять в промт генерации или подавать как relight-правку (Банан умеет переосвещать кадр разговорно). Ключевые команды:

```
Свет — низкий ключ, экспозиция по светам. Единственный источник — жёсткое
солнце из окна [температура: белое нейтральное молочное / тёплое золото —
выбрать и назвать явно, иначе модель уйдёт в golden hour]. Луч прорезает
дымку видимым световым ножом и рисует яркую полосу на [поверхности].
[Субъект] на границе луча: свет скользит по [волосам/плечу/рукам], половина
лица в глубокой тени. Все остальные источники выключены — [лампа/торшер]
тёмный силуэт. Остальная сцена тонет в глубокой тени: детали угадываются,
а не видны. Окно яркое, почти выжженное, с мягким ореолом. Тени глубокие,
чуть дымчатые в самой темноте. Дым/пыль светится в контровом луче.
```

Разбор команд:
- «Экспозиция по светам» — главная: топит кадр ради яркого окна вместо вытягивания теней.
- «Детали угадываются, а не видны» — разрешает спрятать описанную мебель; без этого модель подсвечивает всё перечисленное.
- «Все остальные источники выключены» — явно; смешанный свет двух окон и лампы = ровная пастель.
- Температуру источника называть явно и дублировать запрет контрастом («никакой золотой желтизны») — дефолт моделей для «киношно» это golden hour.

---

## ЧАСТЫЕ ОШИБКИ

| Симптом | Причина | Лечение |
|---------|---------|---------|
| i2i ничего не поменял | Preserve-блок доминирует | Трансформацию первой + STRONG, preserve в одну строку |
| i2i сгенерил другую сцену | Нет SCENE LOCK | Добавить SCENE LOCK с описанием кадра |
| Грейд есть, но «цифра» | Нет halation и lifted blacks | Добавить оба токена явно |
| Пластиковая кожа в видео | Слишком чистые рефы + нет скин-блока | `references/seedance-film.md` |
| Выжженное белое окно/лампа | Нет roll-off | «Soft highlight roll-off — no blown whites» |
| Стиль есть, реализм уплыл | Нет PRIORITY RULE | Добавить PRIORITY RULE из шаблона A |
| Зерно и грейд есть, но «не кино» | Ровный high-key свет | Шаблон C: low-key, экспозиция по светам |
| Грейд из промта игнорируется | Глянцевые рефы перебивают текст | Развести роли рефов / деграднуть рефы (принцип 6) |
| Свет ушёл в жёлтый golden hour | Температура не названа | Назвать явно: «белое нейтральное молочное, никакой желтизны» |
