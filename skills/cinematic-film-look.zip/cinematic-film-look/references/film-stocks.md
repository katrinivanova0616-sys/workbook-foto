# Киностоки — подбор плёнки под настроение и жанр

Указание конкретного стока активирует в модели реальную цветовую науку плёнки (палитра, контраст, структура зерна), а не generic «винтажный фильтр». Один сток на промт — не миксовать.

## Таблица выбора

| Жанр / настроение | Сток | Что даёт | Ключевые токены |
|---|---|---|---|
| Криминальный триллер, интерьеры с лампами, ночь | **Kodak Vision3 500T** | Tungsten-баланс: янтарные лампы, холодные сине-бирюзовые тени, плотное зерно, сильная halation вокруг ламп | `Kodak Vision3 500T, tungsten interior with cool window spill, rich teal shadows, glowing halation around tungsten lights, textured grain` |
| Тёплая драма, портреты, дневной свет | **Kodak Portra 400/800** | Тёплая сливочная кожа, мелкое зерно, мягкий пересвет | `Kodak Portra 400 color science, warm creamy skin tones, slight highlight overexposure, very fine organic grain, green-cyan tint in scanned shadows` |
| Неоновая ночь, город, вывески | **CineStill 800T** | Фирменная красная halation вокруг неона, муди-ночь | `CineStill 800T, signature red halation around neon lights, moody nighttime tones` |
| Ретро 70-х, выцветший семейный архив | **Kodak ColorPlus 200** | Выцветшая тёплая палитра, мягкие края, текстура отпечатка | `Kodak ColorPlus 200 palette, soft focus edges, gentle vignette, scanned print texture, slight color fade` |
| Холодная природа, зелень | **Fujifilm Pro 400H** | Холодноватые зелёные, нежная пастель | `Fujifilm Pro 400H, cool greens, soft pastel rendering` |
| Жёсткий ч/б, документалистика | **Kodak Tri-X 400** | Высокий контраст, тяжёлое зерно | `Kodak Tri-X 400 pushed, high contrast black and white, heavy grain` |
| «Найденная плёнка», хоррор, глитч-ретро | **Expired film** | Светопотёки, сдвиг в пурпур, пыль и царапины | `expired film stock, light leaks from frame edge, purple color shift, dust and scratch textures` |

## Камеры и оптика (усиливают эффект)

- Кино: `Arri Alexa 35` (цифро-кино, мягкая), `shot on 35mm film` (честная плёнка)
- Фото-аналог: `Leica M6`, `Hasselblad 500C` (среднеформатная пластика), `Minolta X-700 vibe` (бытовая 35мм)
- Диафрагма: `f/4` — киношный баланс резкости; `f/1.4–2` только для портретных крупняков

## Универсальные плёночные добавки (к любому стоку)

```
gentle halation and bloom on highlights, lifted milky blacks,
organic film grain denser in shadows, soft highlight roll-off,
slight chromatic aberration at frame edges, subtle vignette,
slight optical softness, no digital sharpening, not AI-clean
```
