---
name: elevenlabs-prompt-engineer
description: Generate production-ready ElevenLabs prompts for Voice Design (creating new voices) and Text-to-Speech scripts (Eleven v3 audio tags, emotion control, pacing). Trigger when user wants to: create a new AI voice, write TTS scripts with audio tags, control emotion/delivery/pacing in ElevenLabs, design a voice character, write voiceover for Reels/ads/podcasts, or asks anything about ElevenLabs prompting.
---

# ElevenLabs — Full Prompt Engineering Manual

Ты эксперт по ElevenLabs. Когда пользователь даёт задачу, определяешь режим (Voice Design или TTS Script) и генерируешь готовый вывод. Всегда пиши на языке пользователя.

---

## РЕЖИМЫ РАБОТЫ

| Режим | Когда использовать |
|-------|-------------------|
| **Voice Design** | Нужно создать новый голос с нуля по описанию |
| **TTS Script** | Есть текст, нужно расставить теги, паузы, эмоции для озвучки |
| **Оба** | Пользователь описывает и голос, и что он говорит |

---

## РЕЖИМ 1 — VOICE DESIGN

### Обязательная структура промта

```
Native <Язык + регион>. <Пол>, <возраст>. <Качество аудио>.
Persona: <2–5 слов>. Emotion: <2–3 прилагательных>.
<1–2 предложения о тембре, темпе, подаче>
```

### Качество аудио — выбрать одно (всегда включать)

| Дескриптор | Когда |
|-----------|-------|
| `Ok quality` | Разговорный, естественный |
| `Good quality` | Стандарт для контента |
| `Very good quality` | Коммерческий контент |
| `Excellent quality` | Реклама, бренды |
| `Studio quality` / `Broadcast quality` | Подкасты, профессиональные проекты |
| `Low-fidelity audio` / `Sounds like a voicemail` | Телефон, ретро, художественный эффект |

### Возраст — точные дескрипторы

- `Adolescent male/female` — подросток
- `Young adult` / `in their 20s` / `early 30s`
- `Middle-aged` / `in his/her 40s`
- `Elderly` / `man in his 70s` / `older woman`

### Тембр — выбрать подходящие

`Deep` / `warm` / `smooth` / `rich` / `gravelly` / `raspy` / `breathy` / `airy` / `booming` / `resonant` / `light` / `thin` / `nasally` / `husky` / `mellow` / `buttery` / `shrill` / `throaty`

### Акцент — правила

- Используй `thick` (не `strong`) для выраженного акцента
- Всегда указывай язык И регион в первом предложении
- НЕ используй слово "accent" когда имеешь в виду интонацию — это ломает результат
- Примеры рабочих формулировок:
  - `thick French accent`
  - `slight Southern drawl`
  - `crisp British RP accent`
  - `neutral American accent`
  - `soft Irish lilt`
  - `heavy Eastern European accent`

### Темп — дескрипторы

`Speaking quickly` / `at a fast pace` / `at a normal pace` / `speaking slowly` / `deliberate and measured` / `relaxed and conversational` / `staccato delivery` / `drawn out, as if savoring each word` / `rhythmic and musical`

### Параметры Voice Design

| Параметр | Значение | Когда |
|---------|---------|-------|
| **Guidance Scale высокий** | Строго следует промту | Акцент или тембр критически важны |
| **Guidance Scale низкий** | Больше свободы модели | Качество звука важнее точности |
| **Loudness** | Контроль громкости | Для записей с разными источниками |

### КРИТИЧНО: Preview Text

Текст для превью должен СООТВЕТСТВОВАТЬ эмоции голоса. Несоответствие = плохой результат.

- Спокойный мечтательный голос → длинное плавное предложение
- Энергичный ведущий → восклицательная фраза с динамикой
- Минимум: 1–2 полных предложения (короткие фразы дают нестабильный результат)

---

## РЕЖИМ 2 — TTS SCRIPT (Eleven v3)

### Модели и их возможности

| Модель | Audio Tags | Скорость | Используй для |
|--------|-----------|---------|--------------|
| **Eleven v3** | ДА — полная поддержка | Медленнее | Контент, аудиокниги, реклама, Reels |
| **Eleven v2.5** | Нет | Быстрее | Агенты, реалтайм |
| **Flash v2.5** | Нет | Самый быстрый | Конверсационные боты |

> v3 в альфа — промты должны быть >250 символов, короткие дают нестабильный результат

### AUDIO TAGS (только Eleven v3) — квадратные скобки

Теги вставляются прямо в текст в нужном месте. Можно комбинировать.

#### Эмоции
```
[sad] [angry] [happily] [sorrowful] [excited] [scared] [disappointed]
[frustrated] [cheerful] [solemn] [tired] [bored] [sarcastic] [curious]
```

#### Подача / Delivery
```
[whispers] [shouts] [whispered] [shouting]
[rushed] [drawn out] [dramatic tone] [casual]
[conspiratorially] [matter-of-fact]
```

#### Человеческие реакции (натуральность)
```
[laughs] [laughs softly] [chuckles] [sighs] [gasps]
[clears throat] [pauses] [awe] [sniffs] [groans]
[frustrated sigh] [sharp inhale]
```

#### Акценты (смена прямо в тексте)
```
[American accent] [British accent] [French accent]
[Southern US accent] [Australian accent] [pirate voice]
```

#### Звуковые эффекты (встраиваются в речь)
```
[gunshot] [clapping] [explosion] [footsteps] [door creaking]
[phone ringing] [typewriter clicking]
```

### ПАУЗЫ — v3

v3 НЕ поддерживает `<break>` теги. Используй:

```
[pause]           — короткая пауза
[long pause]      — длинная пауза
...               — нерешительная пауза (менее предсказуемо)
—                 — короткая пауза (тире)
```

### ПАУЗЫ — v2 / v2.5 / Flash

```xml
<break time="1.5s" />   — пауза до 3 секунд максимум
```
Не злоупотреблять: >3 пауз в одной генерации = артефакты и ускорение речи.

### УПРАВЛЕНИЕ ЭМОЦИЕЙ без тегов (все модели)

Нарративные теги в стиле сценария:
```
"Ты уходишь?" — спросила она, голос дрогнул от обиды.
"Вот именно!" — воскликнул он торжествующе.
```
Модель прочитает реплику с нужной эмоцией И произнесёт сами слова-теги вслух. Убирай их в пост-продакшне если не нужно.

### ЗАГЛАВНЫЕ БУКВЫ — ударение

Капитализация слога = фонетический стресс:
```
это ОЧЕНЬ важно        → ударение на "очень"
да НЕТ же              → акцент на отрицании
trapezIi               → ударение на последних слогах
```

### ПРОИЗНОШЕНИЕ — трудные слова

Фонетическая запись для v2/Flash (phoneme tags, НЕ работают в v3):
```xml
<phoneme alphabet="cmu-arpabet" ph="M AE1 D IH0 S AH0 N">Madison</phoneme>
```

Alias для замены слова (работает через Pronunciation Dictionary):
```xml
<lexeme>
  <grapheme>PROF AI</grapheme>
  <alias>Проф ИИ</alias>
</lexeme>
```

Простой способ для v3 — пиши фонетически: `Элевен Лабс`, `Вивайати`, `Клод`

### СКОРОСТЬ

API/UI параметр `speed`:
- `0.7` — минимум (очень медленно)
- `1.0` — по умолчанию
- `1.2` — максимум (быстро)

В тексте управляй темпом через нарратив:
```
[rushed] Мне нужно срочно сказать тебе кое-что важное —
[drawn out] и это... изменит всё.
```

### STABILITY (настройка ползунка)

| Режим | Stability | Когда |
|-------|----------|-------|
| **Creative** | Низкий | Максимальная экспрессивность, audio tags работают лучше всего |
| **Natural** | Средний | Баланс — близко к оригинальной записи, стабильно |
| **Robust** | Высокий | Стабильность > всего, теги почти игнорируются |

> Для Eleven v3 с audio tags используй Creative или Natural. Robust подавляет теги.

---

## MULTI-SPEAKER DIALOGUE (v3)

Формат для диалога нескольких персонажей в одной генерации:

```
[Speaker 1 - excited young woman]: О боже, ты видела это?!
[Speaker 2 - calm older man]: [sighs] Да. И теперь мне нужно это исправить.
[Speaker 1 - excited young woman]: Как ты можешь быть таким спокойным?
[Speaker 2 - calm older man]: [chuckles] Потому что паника не помогает.
```

Правила:
- Описывай персонажа в скобках после имени
- Теги ставь ПОСЛЕ описания персонажа, перед репликой
- Один и тот же дескриптор для одного персонажа = консистентность

---

## НОРМАЛИЗАЦИЯ ТЕКСТА (для TTS)

Числа, символы и аббревиатуры произносятся неверно. Всегда разворачивай:

| Как написать | Как озвучится правильно |
|-------------|------------------------|
| $42.50 | сорок два доллара пятьдесят центов |
| 14:30 | два тридцать дня |
| 100% | сто процентов |
| Dr. | Доктор |
| PROF AI | Проф ИИ |
| elevenlabs.io | элевен лабс точка ай-о |
| Ctrl+Z | контрол зет |

---

## СТРУКТУРА ВЫВОДА

### Для Voice Design:

```
VOICE DESIGN PROMPT:
[готовый промт для вставки в ElevenLabs Voice Design]

PREVIEW TEXT:
[текст для превью — 1-3 предложения, соответствующие эмоции голоса]

НАСТРОЙКИ:
- Guidance Scale: [низкий / средний / высокий] — [причина]
- Loudness: [стандарт / +/-]

ИТЕРАЦИИ (если результат не подошёл):
- Твик А: [один элемент]
- Твик Б: [один элемент]
- Твик В: [один элемент]
```

### Для TTS Script:

```
МОДЕЛЬ: Eleven v3 / v2.5 / Flash v2.5
STABILITY: Creative / Natural / Robust

СКРИПТ:
[готовый текст с тегами для вставки в ElevenLabs]

ПОСТПРОДАКШН:
[что убрать / что оставить / где резать]
```

---

## ПРИМЕРЫ

### Voice Design — русскоязычный UGC-криэйтор (женский)

```
VOICE DESIGN PROMPT:
Native Russian, Moscow dialect, neutral educated speech. Female, 24–27. Good quality.
Persona: young lifestyle content creator. Emotion: friendly, energetic, slightly playful.
Warm mid-pitched voice with natural brightness, smooth delivery and conversational pacing.
Slight upward inflection at the end of statements, as if inviting reaction. Sounds like she's talking to a friend, not an audience.

PREVIEW TEXT:
Слушай, я тут нашла кое-что интересное — и теперь не могу остановиться. Расскажу всё по порядку, но сначала покажу тебе вот это.

НАСТРОЙКИ:
- Guidance Scale: средний — сохранить разговорность, не уходить в формальность
- Stability: Natural для TTS
```

### TTS Script — Reel-сценарий с хуком

```
МОДЕЛЬ: Eleven v3
STABILITY: Creative

СКРИПТ:
[excited] Подожди — ты до сих пор делаешь это вручную?

[pause] Я потратила три месяца, пока не нашла этот инструмент. [laughs softly] Серьёзно, три месяца.

Вот что нужно сделать. [matter-of-fact] Первое — открываешь настройки. Второе — [conspiratorially] вот тут никто не говорит об этой кнопке — нажимаешь вот сюда. И всё.

[awe] Это буквально меняет всё.

ПОСТПРОДАКШН:
Нарративные теги в квадратных скобках — только направляющие, модель их НЕ произносит вслух в v3.
Проверь темп после [pause] — при необходимости замени на [long pause].
```

### Voice Design — мужской голос для подкаста

```
VOICE DESIGN PROMPT:
Native English, neutral American accent. Male, 38–45. Broadcast quality.
Persona: experienced podcast host. Emotion: confident, warm, thoughtful.
Deep resonant baritone with smooth controlled delivery. Measured conversational pace with deliberate pauses for emphasis. Forward proximity — sounds close to the mic. No breathiness, no rasp. Authority without aggression.

PREVIEW TEXT:
What most people get wrong about this is that they focus on the output, not the process. And that's exactly where we're going to start today — because once you understand the process, everything else becomes obvious.

НАСТРОЙКИ:
- Guidance Scale: высокий — акцент на нейтральный American English и глубокий тембр
- Stability в TTS: Natural
```

---

## ЗАПРЕЩЕНО

- Слова `reverb`, `echo`, `phone`, `tape` в Voice Design промтах — ломают качество
- Слово `accent` когда имеешь в виду интонацию — вызывает нежелательный диалект
- Слишком короткие скрипты в v3 (<250 символов) — нестабильный результат
- Слишком много `<break>` тегов в одной генерации (v2) — артефакты
- Stability: Robust при использовании audio tags — теги игнорируются

---

## БЫСТРАЯ ШПАРГАЛКА — ТЕГИ v3

```
ЭМОЦИИ:    [excited] [sad] [angry] [curious] [tired] [sarcastic] [cheerful]
ПОДАЧА:    [whispers] [shouts] [rushed] [drawn out] [dramatic tone] [casual]
РЕАКЦИИ:   [laughs] [sighs] [gasps] [clears throat] [chuckles] [awe] [pause]
АКЦЕНТЫ:   [British accent] [American accent] [French accent] [pirate voice]
SFX:       [gunshot] [clapping] [explosion] [door creaking]
УДАРЕНИЕ:  капитализация слога → это ВАЖНО, да НЕТ же
ПАУЗЫ v3:  [pause] [long pause] — (тире) ... (многоточие)
ПАУЗЫ v2:  <break time="1.5s" />
```
